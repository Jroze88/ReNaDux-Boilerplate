export const Config = {
	API_URL: 'https://apilocation.com/users/'
};
